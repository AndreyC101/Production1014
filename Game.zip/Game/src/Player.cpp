#include "Player.h"
#include "Engine.h"
#include "TextureManager.h"

Player::Player(PlayerState state) {
	SetState(state);
	SetScale(vec2(30.0f, 30.0f));
	SetObjectType(ObjectType::PLAYER);
	SetMoveSpeed(3.5f);
	SetCollisionRadius(15);
}

void Player::CalculateLampPosition()
{
	/*glm::vec2 spawnPos = glm::vec2(getPosition().x - getWidth() / 2, getPosition().y - getHeight() / 2);
	lampPos = spawnPos + (lightDistance * Util::normalize(glm::vec2(x - getPosition().x, y - getPosition().y)));
	std::cout << "lampPos is " << lampPos.x << " " << lampPos.y << std::endl;
	std::cout << "player Pos is " << getPosition().x << " " << getPosition().y << std::endl;*/
}

void Player::CalculateNewPosition()
{
	m_newPosition = vec2(GetPosition().x + GetVelocity().x, GetPosition().y + GetVelocity().y);
}

void Player::CheckCollisions()
{
}

void Player::CheckTriggers()
{
}

void Player::Move()
{
}

void Player::Update() {
	CalculateLampPosition();
	CalculateNewPosition();
}

void Player::Draw() {
	TextureManager::Instance()->draw("player", GetPosition().x, GetPosition().y, Engine::Instance().GetRenderer(), true);
}