#include "Engine.h"

int main(int argc, char* args[]) {
	return Engine::Instance().Run();
}