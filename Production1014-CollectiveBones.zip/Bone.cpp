#include "Bone.h"
#include "Game.h"


Bone::Bone(const std::vector<glm::vec2> Bone)
{
	TheTextureManager::Instance()->load("../Assets/textures/bone.png", "bone", TheGame::Instance()->getRenderer());
	glm::vec2 size = TheTextureManager::Instance()->getTextureSize("bone");
	setCollisionRadius(20);
	setPosition(glm::vec2(900.0f, 200.0f));
	setWidth(size.x);
	setHeight(size.y);
	setIsColliding(false);
	setType(GameObjectType::RIB);
	TheSoundManager::Instance()->load("../Assets/audio/coin.wav",
		"yay", sound_type::SOUND_SFX);
}

Bone::~Bone()
{
}

void Bone::draw()
{
	TheTextureManager::Instance()->draw("bone", getPosition().x, getPosition().y, TheGame::Instance()->getRenderer(), true);
}

void Bone::update()
{

}

void Bone::clean()
{
}

void Bone::remove()
{
	setPosition(glm::vec2(10000.0f, 10000.0f));
}

bool Bone::Bonestate()
{
	return m_pBonestate;
}