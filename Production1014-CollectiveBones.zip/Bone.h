#pragma once
#ifndef __Bone__
#define __Bone__


#include<vector>
#include "GameObject.h"
#include "TextureManager.h"
#include "SoundManager.h"
class Bone : public GameObject
{
public:
	Bone(const std::vector<glm::vec2> Bone);
	~Bone();

	void draw();
	void update();
	void clean();
	void remove();
	bool Bonestate();
private:
	bool m_pBonestate;



};















#endif /* defined (__Bone__) */
