#include "Rib.h"
#include "Game.h"


Rib::Rib(const std::vector<glm::vec2> Rib)
{
	TheTextureManager::Instance()->load("../Assets/textures/rib.png", "rib", TheGame::Instance()->getRenderer());
	glm::vec2 size = TheTextureManager::Instance()->getTextureSize("rib");
	setCollisionRadius(20);
	setPosition(glm::vec2(1200.0f, 600.0f));
	setWidth(size.x);
	setHeight(size.y);
	setIsColliding(false);
	setType(GameObjectType::RIB);
	TheSoundManager::Instance()->load("../Assets/audio/coin.wav",
		"yay", sound_type::SOUND_SFX);
}

Rib::~Rib()
{
}

void Rib::draw()
{
	TheTextureManager::Instance()->draw("rib", getPosition().x, getPosition().y, TheGame::Instance()->getRenderer(), true);
}

void Rib::update()
{

}

void Rib::clean()
{
}

void Rib::remove()
{
	setPosition(glm::vec2(10000.0f, 10000.0f));
}

bool Rib::Ribstate()
{
	return m_pRibstate;
}