#pragma once
#ifndef __Rib__
#define __Rib__


#include<vector>
#include "GameObject.h"
#include "TextureManager.h"
#include "SoundManager.h"
class Rib : public GameObject
{
public:
	Rib(const std::vector<glm::vec2> Rib);
	~Rib();

	void draw();
	void update();
	void clean();
	void remove();
	bool Ribstate();
private:
	bool m_pRibstate;



};















#endif /* defined (__RIB__) */
