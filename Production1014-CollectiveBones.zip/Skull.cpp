#include "Skull.h"
#include "Game.h"


Skull::Skull(const std::vector<glm::vec2> Skull)
{
	TheTextureManager::Instance()->load("../Assets/textures/Skull.png", "skull", TheGame::Instance()->getRenderer());
	glm::vec2 size = TheTextureManager::Instance()->getTextureSize("skull");
	setCollisionRadius(20);
	setPosition(glm::vec2(70.0f, 600.0f));
	setWidth(size.x);
	setHeight(size.y);
	setIsColliding(false);
	setType(GameObjectType::SKULL);
	TheSoundManager::Instance()->load("../Assets/audio/coin.wav",
		"yay", sound_type::SOUND_SFX);
}

Skull::~Skull()
{
}

void Skull::draw()
{
	TheTextureManager::Instance()->draw("skull", getPosition().x, getPosition().y, TheGame::Instance()->getRenderer(), true);
}

void Skull::update()
{

}

void Skull::clean()
{
}

void Skull::remove()
{
	setPosition(glm::vec2(10000.0f, 10000.0f));
}

bool Skull::Skullstate()
{
	return m_pSkullstate;
}