#pragma once
#ifndef __SKULL__
#define __SKULL__
#include<vector>
#include "GameObject.h"
#include "TextureManager.h"
#include "SoundManager.h"
class Skull : public GameObject
{
public:
	Skull(const std::vector<glm::vec2> Skull);
	~Skull();

	void draw();
	void update();
	void clean();
	void remove();
	bool Skullstate();
private:
	bool m_pSkullstate;



};















#endif /* defined (__Skull__) */
