#include "Map.h"
#include "Game.h"

Map::Map()
{
	TheTextureManager::Instance()->load("../Assets/textures/dungeonMapOne.png", "Map", TheGame::Instance()->getRenderer());
	glm::vec2 size = TheTextureManager::Instance()->getTextureSize("Map");
	setWidth(size.x);
	setHeight(size.y);
	setIsColliding(false);
	setType(GameObjectType::MAP);
}

Map::~Map()
{
}

void Map::draw()
{
	int xComponent = getPosition().x;
	int yComponent = getPosition().y;
	TheTextureManager::Instance()->draw("Map", xComponent, yComponent,
		TheGame::Instance()->getRenderer());
}

void Map::update()
{
	
}

void Map::clean()
{
}

void Map::_move()
{
	
}

void Map::_checkBounds()
{
	
}

void Map::_reset()
{
	
}
