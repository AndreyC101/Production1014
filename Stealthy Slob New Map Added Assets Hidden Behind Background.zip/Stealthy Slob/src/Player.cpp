#include "Player.h"
#include "Game.h"
#include "Wall.h"
#include "Pit.h"
#include "Enemy.h"

Player::Player()
{
	TheTextureManager::Instance()->load("../Assets/textures/player.png", "player", TheGame::Instance()->getRenderer());
	glm::vec2 size = TheTextureManager::Instance()->getTextureSize("player");
	setWidth(size.x);
	setHeight(size.y);
	setIsColliding(false);
	setType(GameObjectType::PLAYER);
}

Player::~Player()
{
}

void Player::draw()
{
	TheTextureManager::Instance()->draw("player", getPosition().x, getPosition().y, TheGame::Instance()->getRenderer(), true);
}

void Player::update()
{
	/*if (m_checkBounds()) {
		m_move();
	}
	else m_newPosition = getPosition();*/
}

void Player::clean()
{
}

void Player::m_move()
{ 
	setPosition(getNewPosition());
}

bool Player::m_checkBounds()
{
	return true;
}

void Player::kill()
{
	m_isAlive = false;
}

bool Player::heartBeatCheck()
{
	return m_isAlive;
}
