#pragma once
#include "GameObject.h"

class Rib : public GameObject {
private:
	SDL_Rect R_collider;
	vec2 R_trigger;
public:
	Rib(RibState state);
	~Rib() {}
	RibState R_state;
	RibState GetState() { return R_state; }
	vec2 GetTrigger() { return R_trigger; }
	void SetState(RibState newState) { R_state = newState; }
	void Update();
	void Draw();
	void remove();
	SDL_Rect GetCollider() { return R_collider; }
	void Clean() {}
};