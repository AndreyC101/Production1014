#include "Skull.h"
#include "TextureManager.h"
#include "Engine.h"

Skull::Skull(SkullState state)
{
}

void Skull::Update()
{
}

void Skull::Draw()
{
	TextureManager::Instance()->draw("Skull", GetPosition().x, GetPosition().y, Engine::Instance().GetRenderer(), true);
}


void Skull::remove()
{
}
