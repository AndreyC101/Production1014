#include "Bone.h"
#include "TextureManager.h"
#include "Engine.h"

Bone::Bone(BoneState state)
{
	SetScale(vec2(25.0f, 25.0f));
	SetObjectType(ObjectType::COLLECTIBLE);
}

void Bone::Update()
{
}

void Bone::Draw()
{
	TextureManager::Instance()->draw("Bone", GetPosition().x, GetPosition().y, Engine::Instance().GetRenderer(), true);
}

void Bone::remove()
{
}
