#pragma once
#include "GameObject.h"

class Bone : public GameObject {
private:
	SDL_Rect B_collider;
	vec2 b_trigger;
public:
	Bone(BoneState state);
	~Bone() {}
	BoneState b_state;
	BoneState GetState() { return b_state; }
	vec2 GetTrigger() { return b_trigger; }
	void SetState(BoneState newState) { b_state = newState; }
	void Update();
	void Draw();
	void remove();
	SDL_Rect GetCollider() { return B_collider; }
	void Clean() {}
};
