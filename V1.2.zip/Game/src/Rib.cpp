#include "Rib.h"
#include "TextureManager.h"
#include "Engine.h"

Rib::Rib(RibState state)
{
}

void Rib::Update()
{
}

void Rib::Draw()
{
	TextureManager::Instance()->draw("Rib", GetPosition().x, GetPosition().y, Engine::Instance().GetRenderer(), true);
}

void Rib::remove()
{
}
