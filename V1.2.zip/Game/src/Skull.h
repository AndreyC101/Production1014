#pragma once
#include "GameObject.h"

class Skull : public GameObject {
private:
	SDL_Rect S_collider;
	vec2 s_trigger;
public:
	Skull(SkullState state);
	~Skull() {}
	SkullState s_state;
	SkullState GetState() { return s_state; }
	vec2 GetTrigger() { return s_trigger; }
	void SetState(SkullState newState) { s_state = newState; }
	void Update();
	void Draw();
	void remove();
	SDL_Rect GetCollider() { return S_collider; }
	void Clean() {}
};